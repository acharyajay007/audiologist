<h2 class="text-center tm10">What would you like to do?</h2>
<hr/>
<div class="row">
<div class="col-sm-3">
</div>
<div class="col-sm-2">
	<center>
	<a  data-page-id="6" class="btn btn-round next-page"><img src="img/new_customer.png"></a>
	<br/><br/><a  data-page-id="6" class="noAnchor selector next-page">Add New Customer</a>
	</center>
</div>
<div class="col-sm-1">
	
</div>
<div class="col-sm-2">
	<center>
	<a data-page-id="5" class="btn btn-round next-page"><img src="img/search_customer.png"></a>
	<br/><br/><a data-page-id="5" class="noAnchor selector next-page"> Search Customer</a>
	</center>
</div>
<div class="col-sm-3">
</div>

</div>