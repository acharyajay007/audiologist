<?php 
include('../include/define.php');
include('../include/function.class.php');
$db=new Functions();
$db=$db->connect();

?>