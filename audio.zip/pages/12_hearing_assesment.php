
<a class="next-page inheritColor" data-page-id="4"><h2 class="text-center">Hearing Assesment</h2></a>
<hr >
<img src="img/page_11.png" class="img-responsive"/>