
<a class="next-page inheritColor" data-page-id="4"><h2 class="text-center">Today we will</h2></a>
<hr >
<img src="img/page_10.png" class="img-responsive"/>