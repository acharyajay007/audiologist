<hr>

<!-- Footer -->
<footer>
	<div class="row">
		<div class="col-lg-12">
			<p>Copyright &copy; <?php echo SITETITLE; ?></p>
		</div>
	</div>
</footer>